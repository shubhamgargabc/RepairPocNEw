﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestPocRepair.Models;

namespace TestPocRepair.Controllers
{
    [HandleError]
    public class IssueRepairsController : Controller
    {
        #region Private Members
        private ApplicationDbContext _aplicationDbContext; 
        #endregion

        #region Constructor
        public IssueRepairsController()
        {
            _aplicationDbContext = new ApplicationDbContext();
        }
        #endregion

        #region Public Methods
        // GET: IssueRepairs
        public ActionResult Index()
        {
            string userRole = ((System.Security.Claims.ClaimsPrincipal)User).Claims.Where(x => x.Type.Contains("role")).Select(x => x.Value).ElementAt(0).ToString();
            Session["UserRole"] = userRole;
            return View(_aplicationDbContext.IssueRepair.ToList());
        }

        public ActionResult RoleBasedIssueList()
        {
            List<IssueStatus> issueStatuses = new List<IssueStatus>();
            string userRole = ((System.Security.Claims.ClaimsPrincipal)User).Claims.Where(x => x.Type.Contains("role")).Select(x => x.Value).ElementAt(0).ToString();
            switch (userRole.ToLower())
            {
                case "clerk":
                    issueStatuses.Add(IssueStatus.New);
                    issueStatuses.Add(IssueStatus.ReadPending);
                    break;
                case "technician":
                    issueStatuses.Add(IssueStatus.ReadPending);
                    issueStatuses.Add(IssueStatus.RepairCompleted);
                    break;
                case "quality control":
                    issueStatuses.Add(IssueStatus.RepairCompleted);
                    issueStatuses.Add(IssueStatus.ReadCompleted);
                    issueStatuses.Add(IssueStatus.QualityApproved);
                    issueStatuses.Add(IssueStatus.QualityRejected);
                    break;
                case "shipping":
                    issueStatuses.Add(IssueStatus.ReadApproved);
                    issueStatuses.Add(IssueStatus.CloseRepair);
                    break;
                default:
                    break;
            }

            return View(_aplicationDbContext.IssueRepair.Where(x => issueStatuses.Any(y => x.IssueStatus == y)));
        }

        // GET: IssueRepairs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IssueRepairModel issueRepair = _aplicationDbContext.IssueRepair.Find(id);
            if (issueRepair == null)
            {
                return HttpNotFound();
            }
            return View(issueRepair);
        }

        // GET: IssueRepairs/Create
        [AuthorizeRole(Roles = "Clerk")]
        public ActionResult Create()
        {
            return View();
        }

        // POST: IssueRepairs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthorizeRole(Roles = "Clerk")]
        public ActionResult Create([Bind(Include = "Id,IssueTitle,IssueDescription,IssueStatus")] IssueRepairModel issueRepair)
        {
            if (ModelState.IsValid)
            {
                issueRepair.IssueStatus = IssueStatus.New;
                issueRepair.IssueCreatedDate = DateTime.Now.ToString();
                _aplicationDbContext.IssueRepair.Add(issueRepair);
                _aplicationDbContext.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(issueRepair);
        }

        // GET: IssueRepairs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IssueRepairModel issueRepair = _aplicationDbContext.IssueRepair.Find(id);
            IssueTrackingModel issueTracking = _aplicationDbContext.IssueTracking.FirstOrDefault(x => x.IssueRepairModel.Id == issueRepair.Id);

            if (issueTracking == null)
            {
                issueTracking = new IssueTrackingModel();
                issueTracking.IssueRepairModel = issueRepair;
            }

            IssueRepairViewModel issueRepairModel = new IssueRepairViewModel();
            issueRepairModel.IssueTracking = issueTracking;

            List<IssueStatus> issueStatuses = new List<IssueStatus>();
            switch (Session["UserRole"].ToString().ToLower())
            {
                case "clerk":
                    issueStatuses.Add(IssueStatus.New);
                    issueStatuses.Add(IssueStatus.ReadPending);
                    if (issueTracking != null)
                    {
                        issueRepairModel.TimeSpent = issueTracking.ClerkTimeSpent;
                    }
                    break;
                case "technician":
                    issueStatuses.Add(IssueStatus.ReadPending);
                    issueStatuses.Add(IssueStatus.RepairCompleted);
                    if (issueTracking != null)
                    {
                        issueRepairModel.TimeSpent = issueTracking.TechnicianTimeSpent;
                    }
                    break;
                case "quality control":
                    issueStatuses.Add(IssueStatus.RepairCompleted);
                    issueStatuses.Add(IssueStatus.ReadCompleted);
                    issueStatuses.Add(IssueStatus.QualityApproved);
                    issueStatuses.Add(IssueStatus.QualityRejected);
                    if (issueTracking != null)
                    {
                        issueRepairModel.TimeSpent = issueTracking.QualityControlTimeSpent;
                    }
                    break;
                case "shipping":
                    issueStatuses.Add(IssueStatus.ReadApproved);
                    issueStatuses.Add(IssueStatus.CloseRepair);
                    if (issueTracking != null)
                    {
                        issueRepairModel.TimeSpent = issueTracking.ShippingTimeSpent;
                    }
                    break;
                default:
                    break;
            }

            issueRepairModel.StatusList = new SelectList(issueStatuses);

            if (issueRepair == null)
            {
                return HttpNotFound();
            }
            return View(issueRepairModel);
        }

        // POST: IssueRepairs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(IssueRepairViewModel issueRepairModel)
        {
            if (ModelState.IsValid)
            {
                string userId = ((System.Security.Claims.ClaimsPrincipal)User).Claims.Where(x => x.Type.Contains("id")).Select(x => x.Value).ElementAt(0).ToString();

                if (issueRepairModel == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                if (issueRepairModel.IssueTracking != null)
                {
                    IssueRepairModel issueRepair = _aplicationDbContext.IssueRepair.Find(issueRepairModel.IssueTracking.IssueRepairModel.Id);
                    issueRepair.IssueStatus = (IssueStatus)Enum.Parse(typeof(IssueStatus), issueRepairModel.CurrentStatus);

                    IssueTrackingModel issuetracking = _aplicationDbContext.IssueTracking.SingleOrDefault(x => x.IssueRepairModel.Id == issueRepair.Id);
                    if (issuetracking != null)
                    {
                        issuetracking.IssueStatus = (IssueStatus)Enum.Parse(typeof(IssueStatus), issueRepairModel.CurrentStatus);
                        switch (Session["UserRole"].ToString().ToLower())
                        {
                            case "clerk":
                                issuetracking.ClerkTimeSpent += issueRepairModel.TimeSpent;
                                break;
                            case "technician":
                                issuetracking.TechnicianTimeSpent += issueRepairModel.TimeSpent;
                                break;
                            case "quality control":
                                issuetracking.QualityControlTimeSpent += issueRepairModel.TimeSpent;
                                break;
                            case "shipping":
                                issuetracking.ShippingTimeSpent += issueRepairModel.TimeSpent;
                                if (issuetracking.IssueStatus == IssueStatus.CloseRepair)
                                {
                                    issueRepair.IssueCloseDate = DateTime.Now.ToString();
                                }
                                break;
                            default:
                                break;
                        }
                        _aplicationDbContext.Entry(issuetracking).State = EntityState.Modified;
                        _aplicationDbContext.SaveChanges();
                    }
                    {
                        issuetracking = new IssueTrackingModel();
                        issuetracking.UserId = userId;
                        issuetracking.IssueStatus = (IssueStatus)Enum.Parse(typeof(IssueStatus), issueRepairModel.CurrentStatus);
                        issuetracking.IssueRepairModel = issueRepair;
                        switch (Session["UserRole"].ToString().ToLower())
                        {
                            case "clerk":
                                issuetracking.ClerkTimeSpent += issueRepairModel.TimeSpent;
                                break;
                            case "technician":
                                issuetracking.TechnicianTimeSpent += issueRepairModel.TimeSpent;
                                break;
                            case "quality control":
                                issuetracking.QualityControlTimeSpent += issueRepairModel.TimeSpent;
                                break;
                            case "shipping":
                                issuetracking.ShippingTimeSpent += issueRepairModel.TimeSpent;
                                if (issuetracking.IssueStatus == IssueStatus.CloseRepair)
                                {
                                    issueRepair.IssueCloseDate = DateTime.Now.ToString();
                                }
                                break;
                            default:
                                break;
                        }
                        _aplicationDbContext.IssueTracking.Add(issuetracking);
                        _aplicationDbContext.SaveChanges();
                    }
                    _aplicationDbContext.Entry(issueRepair).State = EntityState.Modified;
                    _aplicationDbContext.SaveChanges();
                }

                return RedirectToAction("RoleBasedIssueList");
            }
            return View(issueRepairModel);
        }

        public ActionResult IssueReport()
        {
            decimal totalCases = _aplicationDbContext.IssueRepair.Count();
            decimal repairedCases = _aplicationDbContext.IssueRepair.Count(x => x.IssueStatus == IssueStatus.RepairCompleted);
            decimal qualityApproved = _aplicationDbContext.IssueRepair.Count(x => x.IssueStatus == IssueStatus.QualityApproved);

            IssueReportModel issueReportModel = new IssueReportModel();
            issueReportModel.TotalCases = Convert.ToInt32(totalCases);
            if (totalCases != 0)
            {
                issueReportModel.RepairedCasesPercentage = $"{repairedCases / totalCases * 100}%";
                issueReportModel.QualityApprovedCasesPercentage = $"{qualityApproved / totalCases * 100}%";
            }

            return View(issueReportModel);
        }

        public ActionResult IssueTimeSpentReport()
        {
            List<IssueTrackingModel> issueTrackingModelList = _aplicationDbContext.IssueTracking.Include(x => x.IssueRepairModel).ToList();

            return View(issueTrackingModelList);
        }
        #endregion

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _aplicationDbContext.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
