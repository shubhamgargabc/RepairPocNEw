﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestPocRepair.Models
{
    public class IssueTrackingModel
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public IssueStatus IssueStatus { get; set; }
        public int ClerkTimeSpent { get; set; }
        public int TechnicianTimeSpent { get; set; }
        public int QualityControlTimeSpent { get; set; }
        public int ShippingTimeSpent { get; set; }
        public IssueRepairModel IssueRepairModel { get; set; }
    }
}