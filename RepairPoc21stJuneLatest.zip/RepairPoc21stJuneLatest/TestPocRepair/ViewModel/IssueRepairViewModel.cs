﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TestPocRepair.Models
{
    public class IssueRepairViewModel
    {
        //public IssueRepairViewModel()
        //{

        //}

        //public IssueRepairViewModel(List<IssueStatus> values)
        //{
        //    StatusList = new SelectList(values);
        //}

        public IssueTrackingModel IssueTracking { get; set; }
        public SelectList StatusList { get; set; }
        public string CurrentStatus { get; set; }

        [Required]
        public int TimeSpent { get; set; }
    }
}