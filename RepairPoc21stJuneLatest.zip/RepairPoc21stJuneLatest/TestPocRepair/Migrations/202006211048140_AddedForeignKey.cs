namespace TestPocRepair.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedForeignKey : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.IssueTrackingModels", "ClerkTimeSpent", c => c.Int(nullable: false));
            AddColumn("dbo.IssueTrackingModels", "TechnicianTimeSpent", c => c.Int(nullable: false));
            AddColumn("dbo.IssueTrackingModels", "QualityControlTimeSpent", c => c.Int(nullable: false));
            AddColumn("dbo.IssueTrackingModels", "ShippingTimeSpent", c => c.Int(nullable: false));
            AddColumn("dbo.IssueTrackingModels", "IssueRepairModel_Id", c => c.Int());
            CreateIndex("dbo.IssueTrackingModels", "IssueRepairModel_Id");
            AddForeignKey("dbo.IssueTrackingModels", "IssueRepairModel_Id", "dbo.IssueRepairModels", "Id");
            DropColumn("dbo.IssueTrackingModels", "TimeSpent");
        }
        
        public override void Down()
        {
            AddColumn("dbo.IssueTrackingModels", "TimeSpent", c => c.Int(nullable: false));
            DropForeignKey("dbo.IssueTrackingModels", "IssueRepairModel_Id", "dbo.IssueRepairModels");
            DropIndex("dbo.IssueTrackingModels", new[] { "IssueRepairModel_Id" });
            DropColumn("dbo.IssueTrackingModels", "IssueRepairModel_Id");
            DropColumn("dbo.IssueTrackingModels", "ShippingTimeSpent");
            DropColumn("dbo.IssueTrackingModels", "QualityControlTimeSpent");
            DropColumn("dbo.IssueTrackingModels", "TechnicianTimeSpent");
            DropColumn("dbo.IssueTrackingModels", "ClerkTimeSpent");
        }
    }
}
