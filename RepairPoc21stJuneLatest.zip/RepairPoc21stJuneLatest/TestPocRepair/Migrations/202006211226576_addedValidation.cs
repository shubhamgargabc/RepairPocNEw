namespace TestPocRepair.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addedValidation : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.IssueRepairModels", "IssueTitle", c => c.String(nullable: false));
            AlterColumn("dbo.IssueRepairModels", "IssueDescription", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.IssueRepairModels", "IssueDescription", c => c.String());
            AlterColumn("dbo.IssueRepairModels", "IssueTitle", c => c.String());
        }
    }
}
