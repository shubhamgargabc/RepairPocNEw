namespace TestPocRepair.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updatingTables1 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.IssueTrackings", "UserId", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.IssueTrackings", "UserId", c => c.Int(nullable: false));
        }
    }
}
