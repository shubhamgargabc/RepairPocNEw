namespace TestPocRepair.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updatingTables : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.IssueTrackings", "IssueStatus", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.IssueTrackings", "IssueStatus");
        }
    }
}
