namespace TestPocRepair.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdatingIssueTables : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.IssueRepairs", "IssueCreatedDate", c => c.String());
            AlterColumn("dbo.IssueRepairs", "IssueCloseDate", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.IssueRepairs", "IssueCloseDate", c => c.DateTime(nullable: false));
            AlterColumn("dbo.IssueRepairs", "IssueCreatedDate", c => c.DateTime(nullable: false));
        }
    }
}
