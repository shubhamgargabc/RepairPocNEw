namespace TestPocRepair.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class todayupdates : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.IssueRepairs", newName: "IssueRepairModels");
            RenameTable(name: "dbo.IssueTrackings", newName: "IssueTrackingModels");
        }
        
        public override void Down()
        {
            RenameTable(name: "dbo.IssueTrackingModels", newName: "IssueTrackings");
            RenameTable(name: "dbo.IssueRepairModels", newName: "IssueRepairs");
        }
    }
}
