﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TestPocRepair.Models
{
    public class IssueReportModel
    {
        [Display(Name = "Total Cases")]
        public int TotalCases { get; set; }

        [Display(Name = "Repaired Cases Percentage")]
        public string RepairedCasesPercentage { get; set; }

        [Display(Name = "Quality Approved Cases Percentage")]
        public string QualityApprovedCasesPercentage { get; set; }
    }
}