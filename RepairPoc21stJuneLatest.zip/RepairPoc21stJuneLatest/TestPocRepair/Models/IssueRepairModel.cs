﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TestPocRepair.Models
{
    public class IssueRepairModel
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Issue Title")]
        public string IssueTitle { get; set; }

        [Required]
        [Display(Name = "Issue Description")]
        public string IssueDescription { get; set; }

        [Required]
        [Display(Name = "Issue Status")]
        public IssueStatus IssueStatus { get; set; }

        [Display(Name = "Issue CreatedDate")]
        public string IssueCreatedDate { get; set; }

        [Display(Name = "Issue CloseDate")]
        public string IssueCloseDate { get; set; }
    }
}