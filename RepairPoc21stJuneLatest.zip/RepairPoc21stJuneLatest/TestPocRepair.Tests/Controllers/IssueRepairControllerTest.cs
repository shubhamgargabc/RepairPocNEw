﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using TestPocRepair.Controllers;
using TestPocRepair.Models;

namespace TestPocRepair.Tests.Controllers
{
    [TestClass]
    public class IssueRepairControllerTest : Controller
    {
        private IssueRepairsController _controller;
        private ApplicationDbContext _dbContext; 

        [TestInitialize]
        public void InitializeTest()
        {
            _controller = new IssueRepairsController();
            _dbContext = new ApplicationDbContext();
        }

        [TestMethod]
        public void Index()
        {
           // ViewResult result = _controller.Index() as ViewResult;
           // Assert.IsNotNull(result);
        }

        [TestMethod]
        public void IssueReport()
        {
          //  ViewResult result = _controller.IssueReport() as ViewResult;
          //  Assert.IsNotNull(result);
        }

        [TestMethod]
        public void IssueTimeSpentReport()
        {
          //  ViewResult result = _controller.IssueTimeSpentReport() as ViewResult;
          //  Assert.IsNotNull(result);
        }

        [TestMethod]
        public void RoleBasedIssueList()
        {
           // ViewResult result = _controller.RoleBasedIssueList() as ViewResult;
          //  Assert.IsNotNull(result);
        }
    }
}
