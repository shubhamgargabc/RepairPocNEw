﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestPocRepair.Models
{
    public class IssueRepair
    {
        public int Id { get; set; }
        public string IssueTitle { get; set; }
        public string IssueDescription { get; set; }
        public IssueStatus IssueStatus { get; set; }
        public string IssueCreatedDate { get; set; }
        public string IssueCloseDate { get; set; }
    }
}