﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TestPocRepair.Models
{
    public class IssueRepairModel
    {
        public IssueTracking IssueTracking { get; set; }
        public SelectList StatusList { get; set; }
    }
}