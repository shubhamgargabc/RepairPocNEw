﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestPocRepair.Models;

namespace TestPocRepair.Controllers
{
    public class IssueRepairsController : Controller
    {
        private ApplicationDbContext _aplicationDbContext = new ApplicationDbContext();

        public IssueRepairsController()
        {

        }

        // GET: IssueRepairs
        public ActionResult Index()
        {
            return View(_aplicationDbContext.IssueRepair.ToList());
        }

        public ActionResult RoleBasedIssueList()
        {
            List<IssueStatus> issueStatuses = new List<IssueStatus>();
            string userRole = ((System.Security.Claims.ClaimsPrincipal)User).Claims.Where(x => x.Type.Contains("role")).Select(x => x.Value).ElementAt(0).ToString();
            switch (userRole.ToLower())
            {
                case "clerk":
                    issueStatuses.Add(IssueStatus.New);
                    break;
                case "technician":
                    issueStatuses.Add(IssueStatus.New);
                    issueStatuses.Add(IssueStatus.RepairPending);
                    issueStatuses.Add(IssueStatus.RepairCompleted);
                    issueStatuses.Add(IssueStatus.Rejected);
                    break;
                case "quality control":
                    issueStatuses.Add(IssueStatus.RepairCompleted);
                    issueStatuses.Add(IssueStatus.Approved);
                    issueStatuses.Add(IssueStatus.Rejected);
                    break;
                case "shipping":
                    issueStatuses.Add(IssueStatus.Approved);
                    issueStatuses.Add(IssueStatus.CloseRepair);
                    break;
                default:
                    break;
            }

            return View(_aplicationDbContext.IssueRepair.Where(x => issueStatuses.Any(y => x.IssueStatus == y)));
        }

        // GET: IssueRepairs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IssueRepair issueRepair = _aplicationDbContext.IssueRepair.Find(id);
            if (issueRepair == null)
            {
                return HttpNotFound();
            }
            return View(issueRepair);
        }

        // GET: IssueRepairs/Create
        [AuthorizeRole(Roles ="Clerk")]
        public ActionResult Create()
        {
            string userRole = ((System.Security.Claims.ClaimsPrincipal)User).Claims.Where(x => x.Type.Contains("role")).Select(x => x.Value).ElementAt(0).ToString();
            TempData["UserRole"] = userRole;
            return View();
        }

        // POST: IssueRepairs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthorizeRole(Roles = "Clerk")]
        public ActionResult Create([Bind(Include = "Id,IssueTitle,IssueDescription,IssueStatus")] IssueRepair issueRepair)
        {
            if (ModelState.IsValid)
            {
                issueRepair.IssueCreatedDate = DateTime.Now.ToString();
                _aplicationDbContext.IssueRepair.Add(issueRepair);
                _aplicationDbContext.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(issueRepair);
        }

        // GET: IssueRepairs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            string userRole = ((System.Security.Claims.ClaimsPrincipal)User).Claims.Where(x => x.Type.Contains("role")).Select(x => x.Value).ElementAt(0).ToString();
            TempData["UserRole"] = userRole;
            IssueRepair issueRepair = _aplicationDbContext.IssueRepair.Find(id);
            
            List<IssueStatus> issueStatuses = new List<IssueStatus>();
            switch (userRole.ToLower())
            {
                case "clerk":
                    issueStatuses.Add(IssueStatus.New);
                    issueStatuses.Add(IssueStatus.RepairPending);
                    break;
                case "technician":
                    issueStatuses.Add(IssueStatus.New);
                    issueStatuses.Add(IssueStatus.RepairPending);
                    issueStatuses.Add(IssueStatus.RepairCompleted);
                    issueStatuses.Add(IssueStatus.Rejected);
                    break;
                case "quality control":
                    issueStatuses.Add(IssueStatus.RepairCompleted);
                    issueStatuses.Add(IssueStatus.Approved);
                    issueStatuses.Add(IssueStatus.Rejected);
                    break;
                case "shipping":
                    issueStatuses.Add(IssueStatus.Approved);
                    issueStatuses.Add(IssueStatus.CloseRepair);
                    break;
                default:
                    break;
            }


            IssueTracking tracking = new IssueTracking();
            tracking.Id = issueRepair.Id;

            IssueRepairModel issueRepairModel = new IssueRepairModel();
            issueRepairModel.IssueTracking = tracking;
            issueRepairModel.StatusList = new SelectList(issueStatuses);

            if (issueRepair == null)
            {
                return HttpNotFound();
            }
            return View(issueRepairModel);
        }

        // POST: IssueRepairs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,UserId,TimeSpent,IssueStatus")]IssueTracking issueRepairModel)
        {
            if (ModelState.IsValid)
            {
                if (issueRepairModel.Id == 0)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                string userRole = ((System.Security.Claims.ClaimsPrincipal)User).Claims.Where(x => x.Type.Contains("role")).Select(x => x.Value).ElementAt(0).ToString();
                TempData["UserRole"] = userRole;
                string userId = ((System.Security.Claims.ClaimsPrincipal)User).Claims.Where(x => x.Type.Contains("id")).Select(x => x.Value).ElementAt(0).ToString();
               
                IssueRepair issueRepair = _aplicationDbContext.IssueRepair.Find(issueRepairModel.Id);
                _aplicationDbContext.Entry(issueRepair).State = EntityState.Modified;
                _aplicationDbContext.SaveChanges();
                return RedirectToAction("RoleBasedIssueList");
            }
            return View(issueRepairModel);
        }

        // GET: IssueRepairs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IssueRepair issueRepair = _aplicationDbContext.IssueRepair.Find(id);
            if (issueRepair == null)
            {
                return HttpNotFound();
            }
            return View(issueRepair);
        }

        // POST: IssueRepairs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            IssueRepair issueRepair = _aplicationDbContext.IssueRepair.Find(id);
            _aplicationDbContext.IssueRepair.Remove(issueRepair);
            _aplicationDbContext.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _aplicationDbContext.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
