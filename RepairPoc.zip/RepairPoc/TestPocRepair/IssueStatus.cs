﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestPocRepair
{
    public enum IssueStatus
    {
        New,
        RepairPending,
        RepairCompleted,
        Approved,
        Rejected,
        ReadApprovedCase,
        CloseRepair
    }
}