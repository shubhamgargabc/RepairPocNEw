﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestPocRepair.Models
{
    public class IssueTracking
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public int TimeSpent { get; set; }
        public IssueStatus IssueStatus { get; set; }
    }
}