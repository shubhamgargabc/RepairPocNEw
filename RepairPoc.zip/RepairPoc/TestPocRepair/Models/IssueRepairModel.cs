﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TestPocRepair.Models
{
    public class IssueRepairModel
    {
        public int Id { get; set; }
        public string IssueTitle { get; set; }
        public string IssueDescription { get; set; }
        public IssueStatus IssueStatus { get; set; }
        public string IssueCreatedDate { get; set; }
        public string IssueCloseDate { get; set; }
        public SelectList StatusList { get; set; }
        public string UserId { get; set; }
        public int TimeSpent { get; set; }

        public IssueRepairModel()
        {

        }
    }
}